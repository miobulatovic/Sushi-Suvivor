# Sushi Survivor – eigener Server

Dieser Ordner enthält das komplette Spiel **mit** Mehrspieler-Partys und Online-Konten.

- `public/index.html` – das Spiel
- `server.js` – der Server: liefert das Spiel aus, verwaltet Konten (Name + Passwort) und Partys mit 4-stelligem Code
- `package.json` – Startbefehl (keine Zusatzpakete nötig)

Die Konten werden in `data/users.json` gespeichert. Passwörter werden nur verschlüsselt (scrypt-Hash) abgelegt, nie im Klartext.

## Lokal ausprobieren

1. [Node.js](https://nodejs.org) ab Version 18 installieren.
2. Im Ordner ein Terminal öffnen und starten:
   ```
   npm start
   ```
3. Im Browser **http://localhost:3000** öffnen.

Andere Geräte im selben WLAN erreichen das Spiel über die IP-Adresse des Computers, z. B. `http://192.168.0.23:3000`.

## Kostenlos ins Internet stellen (Beispiel: Render)

1. Diesen Ordner als neues Repository auf GitHub hochladen.
2. Auf render.com ein Konto anlegen → **New → Web Service** → das Repository auswählen.
3. Einstellungen:
   - Runtime: **Node**
   - Build Command: leer lassen (oder `npm install`)
   - Start Command: `npm start`
   - Plan: **Free**
4. Nach dem Deploy bekommst du eine Adresse wie `https://sushi-survivor.onrender.com`. Diese Adresse gibst du deinen Freunden.

**Wichtig bei kostenlosen Plänen:**

- Der Server schläft nach etwa 15 Minuten ohne Besucher ein. Der erste Aufruf danach dauert rund eine Minute.
- Kostenlose Pläne haben oft **keinen dauerhaften Speicher**. Dann gehen die Konten bei jedem Neustart oder neuen Deploy verloren. Wenn dein Anbieter ein dauerhaftes Laufwerk („Disk“ oder „Volume“) anbietet, binde es ein und setze die Umgebungsvariable `DATA_DIR` auf dessen Pfad (z. B. `/data`).
- Der Server muss WebSockets erlauben (für die Partys). Das können die meisten Node-Hoster.

## So funktioniert eine Party

1. Spieler 1: **Spielen → Mehrspieler → Party erstellen**. Oben steht ein Code wie `GCGX`.
2. Freunde: **Spielen → Mehrspieler → Party beitreten** und den Code eingeben (bis zu 4 Spieler).
3. Jeder wählt in der Party seine Sushi-Sorte, dann startet der Host.

Der Host berechnet das Spiel und schickt den Spielstand an alle anderen. Wenn der Host die Party verlässt, ist sie für alle beendet. Gegner, Leben und Bosse werden mit mehr Spielern stärker. Wer K.O. geht, kommt in der nächsten Welle mit 40 % Leben zurück.

## Spiel aktualisieren

Neue Version von `index.html` in den Ordner `public` legen und neu deployen.
