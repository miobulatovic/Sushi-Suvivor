// Sushi Survivor – Server für Konten (mit Passwort) und Mehrspieler-Partys mit Code.
// Start: npm install && npm start  → http://localhost:3000
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = process.env.PORT || 3000;
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'users.json');
const PUBLIC = path.join(__dirname, 'public');
fs.mkdirSync(DATA_DIR, { recursive: true });

/* ---------- Konten ---------- */
let users = {};
try { users = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { users = {}; }
const tokenIndex = new Map();
for (const k in users) for (const t of users[k].tokens || []) tokenIndex.set(t, k);

let saveTimer = null;
function saveUsers() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(users));
    fs.renameSync(tmp, DB_FILE);
  }, 400);
}
const NAME_RE = /^[A-Za-z0-9_äöüÄÖÜß]{3,16}$/;
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 64).toString('hex');
function newToken(u) {
  const t = crypto.randomBytes(32).toString('hex');
  u.tokens = [...(u.tokens || []), t].slice(-5);
  tokenIndex.clear();
  for (const k in users) for (const x of users[k].tokens || []) tokenIndex.set(x, k);
  return t;
}
function userFromReq(req) {
  const h = req.headers.authorization || '';
  const t = h.startsWith('Bearer ') ? h.slice(7) : '';
  const k = t && tokenIndex.get(t);
  return k ? { user: users[k], token: t } : null;
}
const emptyData = () => ({ avatar: 0, stats: {}, bt: [], ach: [], best: 0 });
function mergeData(a, b) {
  a = a || emptyData(); b = b || {};
  const out = { avatar: a.avatar, stats: { ...(a.stats || {}) }, bt: [...(a.bt || [])], ach: [...(a.ach || [])], best: a.best || 0 };
  if (Number.isInteger(b.avatar) && b.avatar >= 0 && b.avatar <= 10) out.avatar = b.avatar;
  for (const [k, v] of Object.entries(b.stats || {})) if (typeof v === 'number' && isFinite(v) && v >= 0) out.stats[k] = Math.max(out.stats[k] || 0, v);
  for (const v of b.bt || []) if (Number.isInteger(v) && v >= 0 && v < 9 && !out.bt.includes(v)) out.bt.push(v);
  for (const v of b.ach || []) if (typeof v === 'string' && v.length < 24 && !out.ach.includes(v) && out.ach.length < 64) out.ach.push(v);
  if (typeof b.best === 'number' && b.best >= 0 && b.best <= 100) out.best = Math.max(out.best, Math.floor(b.best));
  return out;
}
// einfache Bremse gegen Passwort-Raten
const attempts = new Map();
function tooMany(ip) {
  const now = Date.now(), a = (attempts.get(ip) || []).filter(x => now - x < 10 * 60 * 1000);
  a.push(now); attempts.set(ip, a);
  return a.length > 30;
}

/* ---------- HTTP ---------- */
function json(res, code, obj) {
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(obj));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let s = '';
    req.on('data', c => { s += c; if (s.length > 50000) { reject(new Error('zu groß')); req.destroy(); } });
    req.on('end', () => { try { resolve(s ? JSON.parse(s) : {}); } catch (e) { reject(e); } });
  });
}
const TYPES = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.json': 'application/json' };

async function handleApi(req, res, route) {
  const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').split(',')[0].trim();
  if (route === 'ping') return json(res, 200, { ok: true });
  if (route === 'register' || route === 'login') {
    if (req.method !== 'POST') return json(res, 405, { error: 'Nur POST' });
    if (tooMany(ip)) return json(res, 429, { error: 'Zu viele Versuche. Bitte warte ein paar Minuten.' });
    let b; try { b = await readBody(req); } catch (e) { return json(res, 400, { error: 'Ungültige Anfrage' }); }
    const name = String(b.user || '').trim(), pass = String(b.pass || ''), key = name.toLowerCase();
    if (route === 'register') {
      if (!NAME_RE.test(name)) return json(res, 400, { error: 'Der Name braucht 3–16 Zeichen (Buchstaben, Zahlen, _).' });
      if (pass.length < 6 || pass.length > 100) return json(res, 400, { error: 'Das Passwort braucht mindestens 6 Zeichen.' });
      if (users[key]) return json(res, 409, { error: 'Dieser Name ist schon vergeben.' });
      const salt = crypto.randomBytes(16).toString('hex');
      users[key] = { user: name, salt, hash: hashPw(pass, salt), created: Date.now(), tokens: [], data: mergeData(emptyData(), b.data) };
      const token = newToken(users[key]); saveUsers();
      return json(res, 200, { token, user: name, data: users[key].data });
    }
    const u = users[key];
    if (!u) return json(res, 401, { error: 'Name oder Passwort ist falsch.' });
    const h = Buffer.from(hashPw(pass, u.salt), 'hex'), ok = crypto.timingSafeEqual(h, Buffer.from(u.hash, 'hex'));
    if (!ok) return json(res, 401, { error: 'Name oder Passwort ist falsch.' });
    const token = newToken(u); saveUsers();
    return json(res, 200, { token, user: u.user, data: u.data });
  }
  const auth = userFromReq(req);
  if (!auth) return json(res, 401, { error: 'Bitte melde dich an.' });
  if (route === 'me') return json(res, 200, { user: auth.user.user, data: auth.user.data });
  if (route === 'sync' && req.method === 'POST') {
    let b; try { b = await readBody(req); } catch (e) { return json(res, 400, { error: 'Ungültige Anfrage' }); }
    auth.user.data = mergeData(auth.user.data, b.data); saveUsers();
    return json(res, 200, { data: auth.user.data });
  }
  if (route === 'logout' && req.method === 'POST') {
    auth.user.tokens = (auth.user.tokens || []).filter(t => t !== auth.token); tokenIndex.delete(auth.token); saveUsers();
    return json(res, 200, { ok: true });
  }
  return json(res, 404, { error: 'Unbekannt' });
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname.startsWith('/api/')) return handleApi(req, res, url.pathname.slice(5)).catch(() => json(res, 500, { error: 'Serverfehler' }));
  let p = decodeURIComponent(url.pathname);
  if (p === '/') p = '/index.html';
  const file = path.normalize(path.join(PUBLIC, p));
  if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
  fs.readFile(file, (err, buf) => {
    if (err) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('Nicht gefunden'); }
    res.writeHead(200, { 'Content-Type': TYPES[path.extname(file)] || 'application/octet-stream' });
    res.end(buf);
  });
});


/* ---------- Mini-WebSocket (ohne Zusatzpakete) ---------- */
const { EventEmitter } = require('events');
class MiniWS extends EventEmitter {
  constructor(sock) {
    super(); this.sock = sock; this.readyState = 1; this.buf = Buffer.alloc(0); this.frag = [];
    sock.setNoDelay(true);
    sock.on('data', d => { this.buf = Buffer.concat([this.buf, d]); this.parse(); });
    const end = () => { if (this.readyState !== 3) { this.readyState = 3; this.emit('close'); } };
    sock.on('close', end); sock.on('error', end); sock.on('end', end);
  }
  get bufferedAmount() { return this.sock.writableLength; }
  parse() {
    while (this.buf.length >= 2) {
      const b0 = this.buf[0], b1 = this.buf[1], fin = b0 & 128, op = b0 & 15, masked = b1 & 128;
      let len = b1 & 127, off = 2;
      if (len === 126) { if (this.buf.length < 4) return; len = this.buf.readUInt16BE(2); off = 4; }
      else if (len === 127) { if (this.buf.length < 10) return; len = Number(this.buf.readBigUInt64BE(2)); off = 10; }
      if (len > 1024 * 1024) return this.terminate();
      const need = off + (masked ? 4 : 0) + len;
      if (this.buf.length < need) return;
      let payload = this.buf.subarray(off + (masked ? 4 : 0), need);
      if (masked) { const k = this.buf.subarray(off, off + 4); payload = Buffer.from(payload); for (let i = 0; i < payload.length; i++) payload[i] ^= k[i & 3]; }
      this.buf = this.buf.subarray(need);
      if (op === 8) { this.frame(8, Buffer.alloc(0)); this.terminate(); return; }
      if (op === 9) { this.frame(10, payload); continue; }
      if (op === 10) { this.emit('pong'); continue; }
      if (op === 1 || op === 2 || op === 0) {
        this.frag.push(payload);
        if (fin) { const all = Buffer.concat(this.frag); this.frag = []; this.emit('message', all); }
      }
    }
  }
  frame(op, data) {
    if (this.sock.destroyed) return;
    const len = data.length; let head;
    if (len < 126) head = Buffer.from([128 | op, len]);
    else if (len < 65536) { head = Buffer.alloc(4); head[0] = 128 | op; head[1] = 126; head.writeUInt16BE(len, 2); }
    else { head = Buffer.alloc(10); head[0] = 128 | op; head[1] = 127; head.writeBigUInt64BE(BigInt(len), 2); }
    this.sock.write(Buffer.concat([head, data]));
  }
  send(s) { if (this.readyState === 1) this.frame(1, Buffer.from(s)); }
  ping() { if (this.readyState === 1) this.frame(9, Buffer.alloc(0)); }
  terminate() { if (this.readyState !== 3) { this.readyState = 3; this.sock.destroy(); this.emit('close'); } }
}
const wsClients = new Set();
server.on('upgrade', (req, sock) => {
  const url = new URL(req.url, 'http://x'), key = req.headers['sec-websocket-key'];
  if (url.pathname !== '/ws' || !key) { sock.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  const ws = new MiniWS(sock); wsClients.add(ws); ws.on('close', () => wsClients.delete(ws));
  onConnection(ws);
});

/* ---------- Partys ---------- */
const rooms = new Map();
const CH = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
function newCode() { let c; do { c = Array.from({ length: 4 }, () => CH[crypto.randomInt(CH.length)]).join(''); } while (rooms.has(c)); return c; }
const send = (ws, o) => { if (ws.readyState === 1) ws.send(JSON.stringify(o)); };
const pub = r => r.members.map(m => ({ id: m.id, name: m.name, av: m.av, sel: m.sel }));
const bc = (r, o) => { const s = JSON.stringify(o); for (const m of r.members) if (m.ws.readyState === 1) m.ws.send(s); };
const lobby = r => bc(r, { t: 'lobby', code: r.code, host: r.host, members: pub(r) });
const clampInt = (v, a, b) => Math.max(a, Math.min(b, Number.isInteger(v) ? v : a));
const cleanName = n => (String(n || 'Spieler').replace(/[^\p{L}\p{N} _.-]/gu, '').trim().slice(0, 16)) || 'Spieler';
function addMember(r, ws, m) {
  ws.room = r; ws.pid = 'p' + (++r.n);
  r.members.push({ id: ws.pid, ws, name: cleanName(m.name), av: clampInt(m.av, 0, 10), sel: clampInt(m.sel, 0, 10) });
}
function leave(ws) {
  const r = ws.room; if (!r) return;
  ws.room = null;
  r.members = r.members.filter(m => m.ws !== ws);
  if (ws.pid === r.host || !r.members.length) {
    for (const m of r.members) { send(m.ws, { t: 'closed' }); m.ws.room = null; }
    rooms.delete(r.code);
  } else { bc(r, { t: 'left', id: ws.pid }); lobby(r); }
}

function onConnection(ws) {
  ws.room = null; ws.alive = true;
  ws.on('pong', () => { ws.alive = true; });
  ws.on('message', raw => {
    let m; try { m = JSON.parse(raw); } catch (e) { return; }
    const r = ws.room;
    if (m.t === 'create') {
      if (r) return;
      const room = { code: newCode(), host: null, members: [], n: 0, playing: false };
      rooms.set(room.code, room); addMember(room, ws, m); room.host = ws.pid;
      send(ws, { t: 'created', code: room.code, id: ws.pid }); lobby(room);
    } else if (m.t === 'join') {
      if (r) return;
      const room = rooms.get(String(m.code || '').toUpperCase());
      if (!room) return send(ws, { t: 'err', msg: 'Keine Party mit diesem Code gefunden.' });
      if (room.members.length >= 4) return send(ws, { t: 'err', msg: 'Die Party ist voll (höchstens 4 Spieler).' });
      if (room.playing) return send(ws, { t: 'err', msg: 'Diese Party spielt gerade. Versuch es nach der Runde.' });
      addMember(room, ws, m); send(ws, { t: 'joined', code: room.code, id: ws.pid }); lobby(room);
    } else if (!r) {
      return;
    } else if (m.t === 'sel') {
      const me = r.members.find(x => x.ws === ws); if (me) { me.sel = clampInt(m.sel, 0, 10); lobby(r); }
    } else if (m.t === 'start') {
      if (ws.pid !== r.host) return;
      r.playing = true; bc(r, { t: 'start', members: pub(r) });
    } else if (m.t === 'lobbyback') {
      if (ws.pid === r.host) { r.playing = false; lobby(r); }
    } else if (m.t === 's') {
      // Spielstand vom Host an alle Gäste weiterreichen
      if (ws.pid !== r.host) return;
      const s = raw.toString();
      for (const x of r.members) if (x.ws !== ws && x.ws.readyState === 1 && x.ws.bufferedAmount < 2e6) x.ws.send(s);
    } else if (m.t === 'in' || m.t === 'pick') {
      // Eingaben der Gäste an den Host
      const h = r.members.find(x => x.id === r.host);
      if (h) { m.from = ws.pid; send(h.ws, m); }
    } else if (m.t === 'leave') {
      leave(ws);
    }
  });
  ws.on('close', () => leave(ws));
}
setInterval(() => { for (const ws of wsClients) { if (!ws.alive) { ws.terminate(); continue; } ws.alive = false; try { ws.ping(); } catch (e) {} } }, 30000);

server.listen(PORT, () => console.log('Sushi Survivor läuft auf Port ' + PORT));
